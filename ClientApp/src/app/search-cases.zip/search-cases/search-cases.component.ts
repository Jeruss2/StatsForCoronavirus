import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-search-cases',
  templateUrl: './search-cases.component.html',
  styleUrls: ['./search-cases.component.css']
})
export class SearchCasesComponent implements OnInit {
  constructor(private http: HttpClient) { }

  public cases:Cases[];

  ngOnInit() {
    this.SearchCases();
  }

  public SearchCases(): boolean {
    console.log("hey im here!");

    this.http.get<Cases[]>("https://localhost:44339/").subscribe(result => { this.cases = result; console.log(result) });

    //this.http.post("https://localhost:4200/api/Listings", this.listing).subscribe(result => {console.log(result)});

    return true;
  }
}

export class Cases {
  totalCases: string;
  totalDeaths: string;
  totalRecoveries: string;
  dateAdded: Date;
}
